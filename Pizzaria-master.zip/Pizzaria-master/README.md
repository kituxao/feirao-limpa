# Pizzaria delivery online.

Projeto realizado com a contribuição do curso Treinaweb de JavaScript. Visando demonstrar o funcionamento de uma pizzaria que realiza pedidos online. Do momento da compra até o cálculo do pedido feito.

[🔗 Clique aqui para acessar!](https://marcelosardo.github.io/Pizzaria/)

## Tecnologias 🛠️

- HTML 
- CSS
- JavaScript
- Git/Github  